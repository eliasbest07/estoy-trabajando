
const Background = () => {
    return (
      <>
        <div className="background blue-purple "></div>
              <div className="background green-blue"></div>
              <div>
              <ul className="circles">
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
                      <li></li>
              </ul>
  
          </div >
      </>
    );
  };
  
  export default Background;